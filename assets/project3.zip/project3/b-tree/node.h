#pragma once

/**
 * Empty implementation. Make sure to read the project description before you
 * start implementing
 *
 * https://iboutsikas.github.io/cmsc341-web/projects/project3/designing_nodes.html
 *
 */

template <typename TKey, typename TIndex>
class Node;


template <typename TKey, typename TIndex>
class Node {

};

